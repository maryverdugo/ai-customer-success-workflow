# AI Customer Success Workflow

**Created by Mary Verdugo**

A practical AI-assisted workflow designed to help Customer Success teams turn a customer inquiry into a clear action plan and follow-up.

## Why I built this

I am learning how AI and workflow automation can improve customer experiences without removing the human element. This project demonstrates how I would use AI to organize customer information, identify needs, draft a response, and create a follow-up plan.

## Workflow

1. Receive customer inquiry
2. AI summarizes the customer's issue
3. AI identifies customer needs, urgency, sentiment, and desired outcome
4. AI suggests a customer-friendly response
5. Human reviews and approves the response
6. Follow-up task is created
7. Customer outcome is recorded
8. Insights can be used to improve future customer experiences

## Example

**Customer inquiry**

> "We started using the platform last week, but our team is confused about how to set up recurring workflows. We tried the documentation but still aren't sure we're doing it correctly. Can someone walk us through it?"

**AI analysis**

- Issue: Difficulty setting up recurring workflows
- Need: Guided onboarding/training
- Urgency: Medium
- Customer sentiment: Frustrated but engaged
- Desired outcome: Successfully create the first recurring workflow

**Suggested next step**

Schedule a short onboarding session, demonstrate the setup using the customer's use case, and send a simple step-by-step follow-up.

## Human-in-the-loop principle

AI supports the Customer Success professional; it does not replace human judgment. A person reviews customer-facing communication before it is sent.

## What I am learning

- Prompt design
- Customer-success workflows
- AI-assisted research and summarization
- Workflow automation
- Human-in-the-loop AI
- Turning customer information into actionable follow-up

## Portfolio note

This is a learning project created to demonstrate practical AI and workflow thinking. It is not connected to customer data or any employer system.
